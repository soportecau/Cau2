There should be 3 files beside this readme in this zip file, they are listed below.

DLMUsbSyncVista.inf
winusb.sys
wceusbsh.inf

On the PC you need to open the local Disk C:, then open Windows, then System32, then the drivers folder.

Copy all 3 of these files into the drivers folder.

Now try connecting the Datalogic device to the PC and let it look for the drivers. After a while it should find them. 

If you tried to sync the device before you copied these files to the PC, it may have already misidentified the device.
To correct the problem, leave the device attached to the PC, open the device manager and locate the unknown device. 
Right click on the device and choose to update the driver. 
Then direct the PC to search in the drivers folder where you copied the files and it should then correct the problem.


 

